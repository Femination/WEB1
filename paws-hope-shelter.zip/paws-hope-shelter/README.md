# Paws & Hope Animal Shelter — Website

**Student:** Mafemani Mongwe
**Student number:** 10516411
**Module:** Web Development — Part 2: Designing the Visuals (CSS Styling and Responsive Design)

A five-page website for Paws & Hope Animal Shelter, a fictional volunteer-run NPO in Johannesburg. The organisation, audience and visual direction were defined in the Part 1 proposal; Part 2 implements that direction as an external stylesheet with a responsive, mobile-first layout.

> Paws & Hope is a fictional organisation created for an academic assignment. Addresses, phone numbers, figures and people are invented.

---

## Contents

- [Pages](#pages)
- [File structure](#file-structure)
- [CSS approach](#css-approach)
- [Responsive design](#responsive-design)
- [Screenshot evidence](#screenshot-evidence)
- [Running the site locally](#running-the-site-locally)
- [Changelog](#changelog)
- [References](#references)

---

## Pages

| Page | File | Purpose |
|---|---|---|
| Home | `index.html` | Hero, shelter figures, animals available this week, where donations go |
| About us | `about.html` | History, mission and vision, spending breakdown, team profiles |
| Get involved | `services.html` | Adoption listings, volunteer roles, donation and sponsorship tiers |
| Enquiry | `enquiry.html` | One form covering adoption, volunteering and sponsorship |
| Contact | `contact.html` | Shelter and adoption centre, emergency line, embedded map, contact form |

## File structure

```
paws-hope-shelter/
├── index.html
├── about.html
├── services.html
├── enquiry.html
├── contact.html
├── css/
│   └── style.css          ← single external stylesheet, linked from all five pages
├── images/                ← hero and card images at multiple widths for srcset
│   ├── hero-shelter-480.jpg / -960.jpg / -1600.jpg
│   └── ...-400.jpg / -800.jpg
├── docs/
│   └── screenshots/       ← responsive evidence (desktop, tablet, mobile)
└── README.md
```

## CSS approach

I used one external stylesheet called `css/style.css` for all five pages. This keeps the design consistent and means I can change the style in one place.

```html
<link rel="stylesheet" href="css/style.css">
```

I used BEM style class names for the main parts of the website. For example, `.card` is the main component, `.card__title` is part of the card, and `.tag--urgent` is a variation of a tag. I also used `l-` for some layout classes such as `.l-wrap` and `.l-grid`.

The CSS starts with the colours, fonts and spacing I wanted to use. I then added a small reset, the normal text styles, the page layouts, buttons, cards, forms and the footer. The responsive rules are at the bottom.

The main colours are teal, yellow, white and cream because they fit the friendly animal shelter theme. I used Poppins for headings and Lato for normal text. I also used different font sizes so that headings are easy to notice and the body text is comfortable to read.

CSS Grid is used for larger page layouts and card sections. Flexbox is used for things like the navigation, buttons and smaller groups of content. I also used `hover`, `active` and `focus-visible` states so links and buttons give visual feedback when they are used.

I added a visible focus style for keyboard users and used `prefers-reduced-motion` so animations can be reduced when a user has that setting enabled.

## Responsive design

I used a mobile first approach. The basic layout is made for a small screen first, and the media queries add more columns and spacing for tablets and desktops. This suits the website because people may visit the shelter site from their phones.

| Screen size | What changes |
|---|---|
| Mobile | Content is mostly one column, buttons are full width and the navigation can wrap. |
| 480px and up | Buttons can sit next to each other, the statistics section becomes a row and forms can use two columns. |
| 768px and up | The header becomes horizontal, cards use two columns and the main content can sit next to images. |
| 1024px and up | Cards use three columns and the contact page can place the map beside the other information. |

I used `rem`, `em`, `%` and `ch` in different places instead of setting everything in pixels. This helps the layout work at different screen sizes.

For images I used `srcset` and `sizes` so the browser can choose an image that is suitable for the screen size. The hero section also uses `<picture>` so a different image can be used at different breakpoints.

I added width and height to the images and used lazy loading on images that are further down the page.

## Screenshot evidence

Captured at three viewport widths. Files are in `docs/screenshots/`.

### Home page

| Desktop — 1440px | Tablet — 768px | Mobile — 390px |
|---|---|---|
| ![Home page at 1440px](docs/screenshots/index-desktop.png) | ![Home page at 768px](docs/screenshots/index-tablet.png) | ![Home page at 390px](docs/screenshots/index-mobile.png) |

### Get involved page

| Desktop — 1440px | Tablet — 768px | Mobile — 390px |
|---|---|---|
| ![Get involved page at 1440px](docs/screenshots/services-desktop.png) | ![Get involved page at 768px](docs/screenshots/services-tablet.png) | ![Get involved page at 390px](docs/screenshots/services-mobile.png) |

### Contact page

| Desktop — 1440px | Tablet — 768px | Mobile — 390px |
|---|---|---|
| ![Contact page at 1440px](docs/screenshots/contact-desktop.png) | ![Contact page at 768px](docs/screenshots/contact-tablet.png) | ![Contact page at 390px](docs/screenshots/contact-mobile.png) |

Testing was done in Chrome DevTools device toolbar and by resizing the browser window, checking each breakpoint for overflow, unreadable line lengths and tap targets that were too small.

## Running the site locally

No build step and no dependencies. Clone the repository and open `index.html` in a browser, or serve the folder:

```bash
python3 -m http.server 8000
# then visit http://localhost:8000
```

## Changelog

Entries are newest first. Use the format `YYYY-MM-DD — area — what changed (and why)`.

### Part 2 — CSS styling and responsive design

- **2026-09-16 — Documentation** — Added the CSS details, responsive sizes and screenshot information to the README.
- **2026-09-16 — Responsive images** — Added responsive image code so smaller screens can use smaller image files.
- **2026-09-16 — Responsive layout** — Added the mobile, tablet and desktop breakpoints.
- **2026-09-16 — Desktop layout** — Added the larger screen layout using Grid and Flexbox.
- **2026-09-16 — Base styles** — Added the basic reset, colours, fonts and text sizes.
- **2026-09-16 — Stylesheet** — Created the external stylesheet and linked it to all five pages.

### Part 1 feedback — corrections applied

<!--
  Replace the placeholder entries below with the actual feedback you received.
  Keep one entry per change, and say what the feedback was and what you did about it.
  Delete any that do not apply.
-->

- **YYYY-MM-DD — [Section of the proposal]** — Lecturer feedback: *[quote or summarise the comment]*. Change made: *[what you corrected]*.
- **YYYY-MM-DD — Wireframes** — Feedback: *[e.g. wireframes needed clearer annotation of the mobile layout]*. Change made: *[what you corrected]*.
- **YYYY-MM-DD — KPIs** — Feedback: *[e.g. KPIs needed measurable targets]*. Change made: *[what you corrected]*.

## References

<!-- Update this list with the sources you actually used, in your module's referencing style. -->

- Mozilla Developer Network. *CSS: Cascading Style Sheets.* https://developer.mozilla.org/en-US/docs/Web/CSS
- Mozilla Developer Network. *Responsive images.* https://developer.mozilla.org/en-US/docs/Web/HTML/Responsive_images
- Mozilla Developer Network. *CSS Grid Layout* and *Flexbox.* https://developer.mozilla.org/en-US/docs/Web/CSS/CSS_Grid_Layout
- Web Content Accessibility Guidelines (WCAG) 2.2. https://www.w3.org/WAI/WCAG22/quickref/
- Google Fonts. *Poppins* and *Lato.* https://fonts.google.com/
